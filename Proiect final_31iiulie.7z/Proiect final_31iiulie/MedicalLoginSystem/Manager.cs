﻿using MedicalLoginSystem; 
using MedicalLoginSystemConsole.Services; 
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using MedicalLoginSystem;
using System.Text.Json;

namespace Proiect
{
    internal class Manager
    {
        public static List<MedicalLoginSystemConsole.Models.User> users = new List<MedicalLoginSystemConsole.Models.User>();
        static Dictionary<string, int> services = new Dictionary<string, int>();
        static List<Service> LoadServices()
        {
            var list = new List<Service>();
            if (!File.Exists("Services.txt")) return list;
            foreach (var line in File.ReadAllLines("Services.txt"))
            {
                try { Service newService=JsonSerializer.Deserialize<Service>(line);
                    list.Add(newService); }
                catch { }
            }
            return list;
        }

        static void SaveServices(List<Service> services)
        {
            foreach (var service in services)
            {
                string line=JsonSerializer.Serialize(service);
                File.WriteAllText("Services.txt",line);
            }
            //File.WriteAllLines("Services.txt", services.Select(s =>
            //    $"{s.Id},{s.Name},{s.Description},{s.Price},{s.Availability}"));
        }

        
        public static void ShowManagerMenu()
        {
        
            Console.WriteLine("\n============Manager Menu=============");
            Console.WriteLine("1-Add users: ");
            Console.WriteLine("2-Remove users: ");
            Console.WriteLine("3-List users: ");
            Console.WriteLine("4-Add Services: ");
            Console.WriteLine("5-Change price of a service: ");
            Console.WriteLine("6-Remove service: ");
            Console.WriteLine("7-Show services: ");
            Console.WriteLine("8-Change number of fidelity points: ");
            Console.WriteLine("0-Go back Register/Login menu");
        }
        public static void ChooseManagerOptions()
        {
        options:
            Console.WriteLine("Select your option");
            string opt = Console.ReadLine();
            switch (opt)
            {
                case "1":
                    AddUsers();
                    break;

                case "2":
                    ListUsers();
                    break;

                case "3":
                    RemoveUsers();
                    break;

                case "4":
                    AddServices();
                    break;

                case "5":
                    ChangePriceOfService();
                    break;

                case "6":
                    RemoveService();
                    break;

                case "7":
                    ShowServices();
                    break;

                case "8":
                    FidPointsMan();
                    break;

                case "0":
                    Console.Clear();
                    UserManager.StartProgram();
                    break;

                default:
                    Console.WriteLine("Choose 1-8");
                    goto options;


            }

            
        }

        static void AddUsers()
        {
            UserManager.Register();
        }

        static void RemoveUsers()
        {
            var filePath = "Users.txt";
            if (!File.Exists(filePath))
            {
                Console.WriteLine("No users found.");
                return;
            }

            var lines = File.ReadAllLines(filePath).ToList();
            if (lines.Count == 0)
            {
                Console.WriteLine("No users to remove.");
                return;
            }


            Console.WriteLine("Users:");
            for (int i = 0; i < lines.Count; i++)
            {
                try
                {
                    var user = System.Text.Json.JsonSerializer.Deserialize<MedicalLoginSystemConsole.Models.User>(lines[i]);
                    if (user != null)
                        Console.WriteLine($"{i + 1}. {user.Email} - {user.Name}");
                }
                catch
                {
                    Console.WriteLine($"{i + 1}. [Invalid user data]");
                }
            }

            Console.Write("Enter the number of the user to remove: ");
            if (int.TryParse(Console.ReadLine(), out int idx) && idx > 0 && idx <= lines.Count)
            {
                lines.RemoveAt(idx - 1);
                File.WriteAllLines(filePath, lines);
                Console.WriteLine("User removed.");
            }
            else
            {
                Console.WriteLine("Invalid selection.");
            }
        }

        public static void LoadUsers()
        {
            var filePath = "Users.txt";
            var lines = File.ReadAllLines(filePath);
            for (int i = 0; i < lines.Length; i++)
            {
                MedicalLoginSystemConsole.Models.User user = System.Text.Json.JsonSerializer.Deserialize<MedicalLoginSystemConsole.Models.User>(lines[i]);
                users.Add(user);
            }
        }

        static void ListUsers()
        {
            if(users.Count()==0)
            {
                Console.WriteLine("No users to display.");
                return;
            }

            Console.WriteLine("Users:");
            foreach (var i in users)
            {
                try
                {
                    if (i != null)
                        Console.WriteLine($"{i.Idu}. {i.Email} - {i.Name}");
                }
                catch
                {
                    Console.WriteLine($"[Invalid user data]");
                }
            }
        }

        static void AddServices()
        {
            var services = LoadServices();

            int newId = services.Any() ? services.Max(s => s.Id) + 1 : 1;

            Console.WriteLine("Enter the name of the service: ");
            string name = Console.ReadLine()?.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                Console.WriteLine("Service name cannot be empty.");
                return;
            }
            if (services.Any(s => s.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                Console.WriteLine("This service already exists.");
                return;
            }

            Console.WriteLine("Enter the description: ");
            string description = Console.ReadLine()?.Trim() ?? "";

            Console.WriteLine("Enter the price: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal price) || price < 0)
            {
                Console.WriteLine("Invalid price.");
                return;
            }

            Console.WriteLine("Enter the availability (true/false): ");
            if (!bool.TryParse(Console.ReadLine(), out bool availability))
            {
                Console.WriteLine("Invalid availability.");
                return;
            }
           

            var service = new Service
            {
                Id = newId,
                Name = name,
                Description = description,
                Price = price,
                Availability= availability

            };
            services.Add(service);
            SaveServices(services);
            Console.WriteLine($"Service {name} added.");
        }
        static void ChangePriceOfService()
        {
            Console.WriteLine("Enter the name of the service you want to change: ");
            string serviceName = Console.ReadLine()?.Trim();
            if (string.IsNullOrWhiteSpace(serviceName) || !services.ContainsKey(serviceName))
            {
                Console.WriteLine("Service not found.");
                return;
            }
            Console.WriteLine("Enter the new price: ");
            if (!int.TryParse(Console.ReadLine(), out int newPrice) || newPrice < 0)
            {
                Console.WriteLine("Invalid price");
                return;
            }
            services[serviceName] = newPrice;
            Console.WriteLine($"Service {serviceName} price changed to {newPrice}.");
            try
            {
                File.WriteAllLines("Services.txt", services.Select(s => $"{s.Key},{s.Value}"));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to update service: {ex.Message}");
            }
        }
        static void RemoveService()
        {
            Console.WriteLine("Enter the name of the service you want to remove: ");

        }
        public static void ShowServices(bool isUser = false, Cart userCart = null)
        {
            var services = LoadServices();
            Console.WriteLine("=== List of Services ===");
            foreach (var service in services)
            {
                Console.WriteLine($"ID: {service.Id} | Name: {service.Name} | Price: {service.Price} | Available: {service.Availability}");
            }

            if (isUser && userCart != null)
            {
                Console.WriteLine("\nEnter the ID of the service to add to your cart (or 0 to finish):");
                while (true)
                {
                    Console.Write("Service ID: ");
                    if (int.TryParse(Console.ReadLine(), out int id) && id != 0)
                    {
                        var selected = services.FirstOrDefault(s => s.Id == id);
                        if (selected != null)
                        {
                            userCart.AddToCart(selected);
                            Console.WriteLine($"Added {selected.Name} to cart.");
                        }
                        else
                        {
                            Console.WriteLine("Service not found.");
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }
        static void FidPointsMan()
        {

        }
    }
}

