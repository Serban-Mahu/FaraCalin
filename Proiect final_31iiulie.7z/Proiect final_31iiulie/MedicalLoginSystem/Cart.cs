﻿using MedicalLoginSystemConsole.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Twilio.Rest.Numbers.V2.RegulatoryCompliance.Bundle;

namespace MedicalLoginSystem
{
    public class Cart
    {
        private static List<Service> services = new List<Service>();
        public int Id{ get; set; }
        public static decimal totalPrice = services.Sum(item => item.Price);
        public void AddToCart(Service service)
        {
            services.Add(service);
            SaveCart(); 
        }

        public void SaveCart(string filePath = "cart.txt")
        {   
            List<string> lines = new List<string>();
            lines.Add($"{Id}");
            File.WriteAllLines(filePath,lines);
            File.WriteAllLines(filePath, services.Select(s =>
                $"{s.Id}|{s.Name}|{s.Description}|{s.Price}|{s.Availability}"));
            lines.Clear();
            lines.Add("");
            File.WriteAllLines(filePath,lines);
        }

        public void LoadCart(string filePath = "cart.txt")
        {
            services.Clear();
            Id=User.currUser;
            if (!File.Exists(filePath)) return;
            foreach (var line in File.ReadAllLines(filePath))
            {
                try { bool found= false;
                    if (line == Id.ToString())
                        found = true;
                    if(found&&(line!=Id.ToString()&&line!=" "))
                        services.Add(Service.FromString(line));
                    if(found&&line == "")
                        break;
                }
                catch { }
            }
        }

        public void ShowCart()
        {
            LoadCart(); 
            if (services.Count == 0)
            {
                Console.WriteLine("Cart is empty.");
                return;
            }
            foreach (var s in services)
            {
                Console.WriteLine($"ID: {s.Id} | Name: {s.Name} | Price: {s.Price}");
            }
            Console.ResetColor();
            Console.WriteLine("\n Would you like to proceed with your order? ");

            Console.Write("(");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Y");
            Console.ResetColor();
            Console.Write("/");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("N");
            Console.ResetColor();
            Console.Write("): ");

            switch (Console.ReadLine()?.ToUpper())
            {
                case "Y":

                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(" Proceeding with your order...");
                    Console.ResetColor();

                    totalPrice = Discounts.ApplyFidelityPointsDiscount(totalPrice);

                    break;

                case "N":
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Order cancelled.");
                    Console.ResetColor();
                    break;

                default:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" Invalid choice. Returning to main menu.");
                    Console.ResetColor();
                    Thread.Sleep(2000);
                    Console.Clear();
                    break;
            }
        }
    }
}