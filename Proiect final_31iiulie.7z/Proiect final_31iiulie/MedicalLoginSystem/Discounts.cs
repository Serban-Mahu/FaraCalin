﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

using System.Security.Cryptography;

namespace MedicalLoginSystem
{
    internal class Discounts
    {

        public static decimal ApplyFidelityPointsDiscount(decimal totalPrice)
        {
            if (MedicalLoginSystemConsole.Models.User.FidelityPoints > 100)
            {
                Console.WriteLine($" You have {MedicalLoginSystemConsole.Models.User.FidelityPoints} fidelity points.");
                Console.Write(" Would you like to use them for a discount? (Y/N): ");
                string usePoints = Console.ReadLine()?.Trim().ToUpper();

                if (usePoints == "Y")
                {
                    decimal discount = 0m;
                    if (MedicalLoginSystemConsole.Models.User.FidelityPoints >= 100 && MedicalLoginSystemConsole.Models.User.FidelityPoints <= 299)
                        discount = 0.10m;
                    else if (MedicalLoginSystemConsole.Models.User.FidelityPoints >= 300 && MedicalLoginSystemConsole.Models.User.FidelityPoints <= 499)
                        discount = 0.20m;
                    else if (MedicalLoginSystemConsole.Models.User.FidelityPoints >= 500)
                        discount = 0.30m;

                    if (discount > 0)
                    {
                        decimal discountAmount = totalPrice * discount;
                        totalPrice -= discountAmount;
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($" Your total after applying fidelity points is: {totalPrice:C}");
                        Console.ResetColor();
                        MedicalLoginSystemConsole.Models.User.FidelityPoints = 0;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine(" Fidelity points not used.");
                        Console.ResetColor();
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($" Your total is: {totalPrice:C}");
                    Console.ResetColor();
                }
                MedicalLoginSystemConsole.Models.User.FidelityPoints = 0;
            }
            return totalPrice;
        }
    }
}