﻿using System;
using System.Collections.Generic;
using System.IO;

namespace MedicalLoginSystem
{
    public static class OrdersManager
    {
        private static readonly string filePath = "Orders.txt";

        public static void SaveOrder(int userId, decimal totalAmount)
        {
            string line = $"{userId}|{totalAmount}|{DateTime.Now}";
            File.AppendAllText(filePath, line + Environment.NewLine);
        }

        public static List<OrderRecord> LoadOrders()
        {
            var orders = new List<OrderRecord>();
            if (!File.Exists(filePath)) return orders;

            var lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                var parts = line.Split('|');
                if (parts.Length == 3 &&
                    int.TryParse(parts[0], out int userId) &&
                    decimal.TryParse(parts[1], out decimal total) &&
                    DateTime.TryParse(parts[2], out DateTime date))
                {
                    orders.Add(new OrderRecord
                    {
                        UserId = userId,
                        TotalAmount = total,
                        OrderDate = date
                    });
                }
            }

            return orders;
        }

        public class OrderRecord
        {
            public int UserId { get; set; }
            public decimal TotalAmount { get; set; }
            public DateTime OrderDate { get; set; }
        }
    }
}
