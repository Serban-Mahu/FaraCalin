﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using MedicalLoginSystemConsole.Models;
using System.Text.Json;
using Proiect;

namespace MedicalLoginSystem
{
    public class Cart
    {
        private List<Service> services = new List<Service>();

        
        public IReadOnlyList<Service> Services => services.AsReadOnly();

        
        public void AddService(Service service)
        {
            services.Add(service);
        }

       
        public decimal GetTotal()
        {
            return services.Sum(s => s.Price);
        }

        
        public void ShowCart()
        {
            Console.WriteLine("\n Your Cart:");
            if (services.Count == 0)
            {
                Console.WriteLine(" (empty)");
            }
            else
            {
                foreach (var service in services)
                {
                    Console.WriteLine($" - {service.Name}: {service.Price:C}");
                }
                Console.WriteLine($" Total: {GetTotal():C}");
            }
        }

        
        public void SaveCart()
        {
            string filePath = $"cart_{User.currUser}.json";
            var json = JsonSerializer.Serialize(services, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }

        
        public void LoadCart()
        {
            string filePath = $"cart_{User.currUser}.json";
            services.Clear();

            if (!File.Exists(filePath)) return;

            try
            {
                var loadedServices = JsonSerializer.Deserialize<List<Service>>(File.ReadAllText(filePath));
                if (loadedServices != null)
                {
                    services.AddRange(loadedServices);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Eroare la încărcarea cart-ului: {ex.Message}");
            }
        }

        
        public void Clear()
        {
            services.Clear();
        }
        public List<Service> GetServices()
        {
            return services;
        }

    }
}
