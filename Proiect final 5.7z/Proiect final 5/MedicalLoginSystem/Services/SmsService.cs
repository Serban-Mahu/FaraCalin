﻿using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace MedicalLoginSystemConsole.Services
{
    public static class SmsService
    {
        public static string LatestCode { get; private set; }

        private static readonly string accountSid = "AC7894d86b4bbc4a8bde0197891a585934";
        //AC8883a1e050ceef2b55e104ec4f112738";
        private static readonly string authToken = "4f13c7f011ceaa484576150a1c8fdf14";
            //"eb7c9d1ea5ee5befb4ee0e84725454e4";
        private static readonly string fromPhone = "+17632848901";

        public static void SendCode(string toPhone)
        {
            TwilioClient.Init(accountSid, authToken);

            var random = new Random();
            LatestCode = random.Next(100000, 999999).ToString();

            MessageResource.Create(
                body: $"Your verification code is {LatestCode}",
                from: new PhoneNumber(fromPhone),
                to: new PhoneNumber(toPhone)
            );
        }
    }
}