﻿using System;
using System.Collections.Generic;
using System.Linq;
using MedicalLoginSystemConsole.Models;
using Proiect;

namespace MedicalLoginSystem
{
    internal class Order
    {
        public List<Service> OrderedServices { get; set; } = new List<Service>();
        public decimal TotalAmount { get; private set; }

        public void CreateOrder(List<Service> servicesInCart)
        {
            OrderedServices = new List<Service>(servicesInCart);
            TotalAmount = OrderedServices.Sum(s => s.Price);

            Console.WriteLine($"\n Total before discount: {TotalAmount:C}");
            TotalAmount = Discounts.ApplyFidelityPointsDiscount(TotalAmount);

            
            foreach (var service in OrderedServices)
            {
                var actualService = Manager.services.FirstOrDefault(s => s.Id == service.Id);
                if (actualService != null)
                {
                    if (actualService.AvailableSlots > 0)
                    {
                        actualService.AvailableSlots--;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($" Nu mai sunt locuri disponibile pentru: {actualService.Name}");
                        Console.ResetColor();
                        return;
                    }
                }
            }

            
            typeof(Manager).GetMethod("SaveServices", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)
                           .Invoke(null, null);

            ProcessOrder();
       
        }

        private void ProcessOrder()
        {
            var userId = User.currUser; 

            Console.WriteLine($"\nApplying fidelity points discount if available...");

           
            TotalAmount = Discounts.ApplyFidelityPointsDiscount(TotalAmount);

            Console.WriteLine($"Total amount after discount: {TotalAmount:C}");

          
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Order completed successfully!");
            Console.ResetColor();

           
            int earnedPoints = (int)(TotalAmount / 10);
            int currentPoints = FidelityManager.GetPoints(userId);
            FidelityManager.SetPoints(userId, currentPoints + earnedPoints);

            
            OrdersManager.SaveOrder(userId, TotalAmount);
        }

    }
}



