﻿using MedicalLoginSystem;

namespace MedicalLoginSystemConsole.Models
{
    public class User
    {
        public int Idu { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
        public string Phone { get; set; }

        public static int totalUsers = 0;

        public static int currUser;
        public int FidelityPoints = 0;
        
        public decimal BankBalance { get; set; } = 10000;
        
        public Cart UserCart { get; set; } = new Cart();
        public User(string email, string name, string password, string role, string phone)
        {
            Idu = totalUsers;
            totalUsers++;
            Email = email;
            Name = name;
            Password = password;
            Role = role;
            Phone = phone;
            UserCart = new Cart();
        }

        public override string ToString() => $"{Email},{Name},{Password},{Role},{Phone}";

        public static User FromString(string line)
        {
            var parts = line.Split(',');
            if (parts.Length != 6)
                throw new FormatException("Invalid user data format.");

            return new User (parts[1], parts[2], parts[3], parts[4], parts[5]);
        }
    }
}