﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MedicalLoginSystem
{
    public static class FidelityManager
    {
        private static readonly string filePath = "FidelityPoints.txt";

        public static int GetPoints(int userId)
        {
            if (!File.Exists(filePath)) return 0;

            var lines = File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                var parts = line.Split('|');
                if (int.TryParse(parts[0], out int id) && id == userId)
                {
                    return int.Parse(parts[1]);
                }
            }
            return 0;
        }

        public static void SetPoints(int userId, int points)
        {
            var lines = File.Exists(filePath) ? File.ReadAllLines(filePath).ToList() : new List<string>();
            bool updated = false;

            for (int i = 0; i < lines.Count; i++)
            {
                var parts = lines[i].Split('|');
                if (int.TryParse(parts[0], out int id) && id == userId)
                {
                    lines[i] = $"{id}|{points}";
                    updated = true;
                    break;
                }
            }

            if (!updated)
                lines.Add($"{userId}|{points}");

            File.WriteAllLines(filePath, lines);
        }

        public static void ResetPoints(int userId) => SetPoints(userId, 0);
    }
}
