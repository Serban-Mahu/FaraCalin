﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace tema_22_iul
{
    internal class Manager
    {
        public User[] users = new User[100];
        public int i = 0;
        public Manager()
        {
            LoadFromFile();
        }
        public void LoadFromFile()
        {   
            User temp = new User();
            using (FileStream fs = new FileStream("users.txt", FileMode.OpenOrCreate))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.Contains("User "))
                        {
                            temp = new User();
                            temp.ID = uint.Parse(line.Substring(line.IndexOf(" ") + 1));
                        }
                        if (line.Contains("Username: "))
                        {
                            temp.Username = line.Substring(line.IndexOf(":") + 2);
                        }
                        if (line.Contains("Password: "))
                        {
                            temp.Password = line.Substring(line.IndexOf(":") + 2);
                        }
                        if (line.Contains("Email: "))
                        {
                            temp.Email = line.Substring(line.IndexOf(":") + 2);
                            users[i] = temp;
                            i++;
                        }
                    }
                }
            }
        }

        public void SaveToFile(User newUser)
        {
            using (StreamWriter sw = new StreamWriter("users.txt", true))
            {
                sw.WriteLine($"User {newUser.ID}");
                sw.WriteLine();
                sw.WriteLine($"Username: {newUser.Username}");
                sw.WriteLine($"Password: {newUser.Password}");
                sw.WriteLine($"Email: {newUser.Email}");
                sw.WriteLine("=====");
            }
        }

        public void printUsers()
        {
            for (int j = 0; j < i; j++)
            {
                Console.WriteLine($"User {users[j].ID}");
                Console.WriteLine($"Username: {users[j].Username}");
                Console.WriteLine($"Password: {users[j].Password}");
                Console.WriteLine($"Email:    {users[j].Email}");
                Console.WriteLine();
            }
        }
    }
}
