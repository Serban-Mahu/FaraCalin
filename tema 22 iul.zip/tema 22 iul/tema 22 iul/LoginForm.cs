﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tema_22_iul
{
    internal class LoginForm
    {
        Manager manager = new Manager();
        private string currUsername;
        public LoginForm()
        {
        }
        private string _username, _password;
        public string Username { get => _username; set => _username = value; }
        public string Password { get => _password; set => _password = value; }

        public void Show()
        {
            Console.WriteLine();
            Console.Write("Username: ");
            _username = Console.ReadLine();
            Console.Write("Password: ");
            _password = Console.ReadLine();
            if (Validate())
            {
                Console.WriteLine("Login successful!");
                Console.WriteLine($"Welcome, {currUsername}!");
                Console.WriteLine("Press any key to close the login form.");
                Console.ReadKey();
                Close();
            }
            else
            {
                Console.WriteLine("Invalid username or password. Please try again.");
                Show();
            }
        }

        public bool Validate()
        {
            for (int i = 0; i < manager.i; i++)
            {
                if (manager.users[i] != null)
                {
                    if (manager.users[i].Username == _username && manager.users[i].Password == _password)
                    {
                        currUsername = manager.users[i].Username;
                        return true;
                    }
                }
            }
            return false;
        }

        public void Close()
        {
            Console.Clear();
            Console.WriteLine("Login form closed.");

        }
    }
}
