﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tema_22_iul
{
    internal class RegistrationForm
    {
        private string _username, _password, _email;
        private uint _ID;

        Manager manager = new Manager();
        public string Username { get => _username; set => _username = value; }
        public string Email { get => _email; set => _email = value; }
        public string Password { get => _password; set => _password = value; }
        public uint ID { get => _ID; set => _ID = value; }

        public void Show()
        {
            Console.Write($"Username: ");
            _username = Console.ReadLine();
            Console.Write("Email: ");
            _email = Console.ReadLine();
            Console.Write("Password: ");
            _password = Console.ReadLine();
            if (Validate())
            {
                Console.WriteLine("Registration successful!");
                Console.WriteLine("Press any key to close the registration form.");
                Console.ReadKey();
                manager = new Manager();
                _ID = (uint)(manager.i);
                manager.i++;
                User newUser = new User { Username = _username, Email = _email, Password = _password, ID = _ID };
                manager.SaveToFile(newUser);
            }
            else { Console.WriteLine("Please try again: "); Show(); }
            Close();
        }

        public bool Validate()
        {   
            manager= new Manager();
            for (int i = 0; i < manager.i; i++)
            {
                if (manager.users[i] != null)
                {
                    if (manager.users[i].Username == _username)
                    {
                        Console.WriteLine("Username already exists!");
                        return false;
                    }
                    if (manager.users[i].Email == _email)
                    {
                        Console.WriteLine("Email already exists!");
                        return false;
                    }
                    else
                    {
                        if(_email.Contains("@") == false || _email.Contains(".") == false)
                        {
                            Console.WriteLine("Email is not valid!");
                            return false;
                        }
                    }
                    if (_password.Length < 9)
                    {
                        Console.WriteLine("Password is too short!");
                        return false;
                    }
                }
            }
            return true;
        }

        public void Close()
        {
            Console.Clear();
            Console.WriteLine("Registration form closed.");
            Console.WriteLine("Would you like to log in? (Y/N)");
            char choice = Console.ReadKey().KeyChar;
            if (choice=='Y')
            {
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
            }
        }
    }
}
