﻿namespace tema_22_iul
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Would you like to register (R), log in (L), or see the user data (M, password needed)? ");
            string choice = Console.ReadLine().ToUpper();
            switch (choice)
            {
                case "R":
                    RegistrationForm registrationForm = new RegistrationForm();
                    registrationForm.Show();
                    break;
                case "L":
                    LoginForm loginForm = new LoginForm();
                    loginForm.Show();
                    break;
                case "M":
                    Console.Write("Please enter the password: ");
                    string password = Console.ReadLine();
                    if(password=="12345678")
                    {
                        Manager manager = new Manager();
                        manager.printUsers();
                    }
                    else
                    {
                        Console.WriteLine("Incorrect password. Access denied.");
                    }
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    Main(args);
                    break;
            }
        }
    }
}
