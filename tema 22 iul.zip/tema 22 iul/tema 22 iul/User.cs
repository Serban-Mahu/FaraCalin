﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace tema_22_iul
{
    internal class User
    {

        private string _username,_password,_email;
        private uint _ID;

        public string Username { get => _username; set => _username = value; }
        public string Password { get => _password; set => _password = value; }
        public string Email { get => _email; set => _email = value; }
        public uint ID { get => _ID; set => _ID = value; }
        public User() { }
    }
}
