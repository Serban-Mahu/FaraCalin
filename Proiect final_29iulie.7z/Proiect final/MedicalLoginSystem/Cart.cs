﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MedicalLoginSystem
{
    public class Cart
    {
        private static List<Service> items = new List<Service>();

        
        public static void ViewCart()
        {
            if (items.Count == 0)
            {
                Console.WriteLine("Your cart is empty.");
                return;
            }

            Console.WriteLine("Your cart contains:");
            int i = 1;
            foreach (var service in items)
            {
                Console.WriteLine($"{i++}. {service.Name} - {service.Price:C}");
            }
        }

       
        public void AddToCart(Service service)
        {
            items.Add(service);
        }

        
    }
}