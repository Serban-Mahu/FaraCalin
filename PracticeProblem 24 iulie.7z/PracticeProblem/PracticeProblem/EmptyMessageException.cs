﻿// EmptyMessage.cs
using System;

namespace PracticeProblem
{
    public class EmptyMessageException : Exception
    {
        public EmptyMessageException(string msg) : base(msg) { }
    }
}