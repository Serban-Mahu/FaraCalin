﻿// Message.cs
using System;

namespace PracticeProblem
{
    public class Message
    {
        public Person Sender { get; set; }
        public Person Receiver { get; set; }
        public DateTime Date { get; set; }
        private string _text;
        public bool Seen { get; set; }

        public string Text
        {
            get => _text;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new EmptyMessageException("Message content cannot be empty");
                _text = value;
            }
        }
    }
}