﻿// TXTReader.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Globalization;

namespace PracticeProblem
{
    public class TXTReader
    {
        private string _path;
        private Dictionary<int, Person> _people;

        public TXTReader(string path, Dictionary<int, Person> people)
        {
            _path = path;
            _people = people;
        }

        public List<Message> ReadMessages()
        {
            var messages = new List<Message>();

            using (var reader = new StreamReader(_path))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    try
                    {
                        var parts = line.Split(new[] { "##" }, StringSplitOptions.None);
                        if (parts.Length < 4) continue;

                        var dateAndSender = parts[0].Split('#');
                        DateTime date = DateTime.Parse(dateAndSender[0], CultureInfo.InvariantCulture);

                        var senderInfo = ExtractPerson(dateAndSender[1]);
                        var receiverInfo = ExtractPerson(parts[1]);
                        string text = parts[2];
                        bool seen = bool.Parse(parts[3]);

                        messages.Add(new Message
                        {
                            Sender = GetOrCreatePerson(senderInfo),
                            Receiver = GetOrCreatePerson(receiverInfo),
                            Date = date,
                            Text = text,
                            Seen = seen
                        });
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Eroare la linia: {line}\n{ex.Message}");
                    }
                }
            }

            return messages;
        }

        private (int Id, string Name, string Email) ExtractPerson(string raw)
        {
            int start = raw.IndexOf('(');
            int end = raw.IndexOf(')');
            string name = raw.Substring(0, start);
            string[] details = raw.Substring(start + 1, end - start - 1).Split(',');
            int id = int.Parse(details[0]);
            string email = details[1];
            return (id, name.Trim(), email.Trim());
        }

        private Person GetOrCreatePerson((int Id, string Name, string Email) info)
        {
            if (!_people.ContainsKey(info.Id))
                _people[info.Id] = new Person { Id = info.Id, Name = info.Name, Email = info.Email };
            return _people[info.Id];
        }
    }
}