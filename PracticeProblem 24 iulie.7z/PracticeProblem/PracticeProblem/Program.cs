﻿// Program.cs
using System;

namespace PracticeProblem
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager manager = new Manager();

            var person101 = manager.GetPerson(101);
            var person201 = manager.GetPerson(201);

            if (person101 == null || person201 == null)
            {
                Console.WriteLine("Una dintre persoanele cu ID 101 sau 201 nu există.");
                return;
            }

            manager.PrintUniquePersons();
            manager.CountMessagesBetween(person101, person201);
            manager.PrintMessagesBetween(person101, person201);
            manager.PrintMessagesByDate(new DateTime(2024, 6, 10));
            manager.PrintMessagesBySender(person101);
            manager.SaveMessagesBetween(person101, person201, "MessagesBetween.txt");
            manager.PrintUnseenMessages();
            manager.ShowLastMessageWithForbidden(person201, "hello");

            Console.WriteLine("\n--- All Messages for Person 101 ---");
            manager.PrintAllMessagesOfPerson(person101);

            Console.WriteLine("\n--- Messages Grouped by Part of Day ---");
            manager.GroupMessagesByPartOfDay();

            Console.WriteLine("\n--- Search Messages for Keyword 'hello' for Person 201 ---");
            manager.SearchMessagesByKeyword(person201, "hello");

            Console.WriteLine("\n--- Person-Correspondents Structure ---");
            var correspondents = manager.GetPersonCorrespondentsStructure();
            foreach (var entry in correspondents)
            {
                Console.WriteLine($"{entry.Person.Name}'s correspondents:");
                foreach (var c in entry.Correspondents)
                    Console.WriteLine("  - " + c.Name);
            }
        }
    }
}