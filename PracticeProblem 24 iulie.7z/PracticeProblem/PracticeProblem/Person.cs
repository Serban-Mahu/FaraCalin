﻿// Person.cs

namespace PracticeProblem
{
    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

        public override bool Equals(object obj) => obj is Person p && p.Id == Id;
        public override int GetHashCode() => Id.GetHashCode();
    }
}