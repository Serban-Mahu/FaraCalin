﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PracticeProblem
{
    //Implements static method to print formatted Messages at console and to save them in a file
    internal class OutputHelper
    {
        public static void PrintMessages(List<Message> messages)
        {
            foreach (Message message in messages)
            {
                Console.WriteLine(message);
            }
            Console.WriteLine();
        }

        // Complete this class with other methods
    }
}
