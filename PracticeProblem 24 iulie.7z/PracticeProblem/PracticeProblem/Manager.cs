﻿// Manager.cs
using System;
using System.Collections.Generic;
using System.Linq;

namespace PracticeProblem
{
    public class Manager
    {
        private List<Message> messages = new List<Message>();
        private Dictionary<int, Person> people = new Dictionary<int, Person>();

        public Manager()
        {
            var reader = new TXTReader("Messages.txt", people);
            messages = reader.ReadMessages();
        }

        public Person GetPerson(int id) => people.ContainsKey(id) ? people[id] : null;

        public void PrintUniquePersons()
        {
            var unique = messages.SelectMany(m => new[] { m.Sender, m.Receiver }).Distinct();
            foreach (var p in unique)
                Console.WriteLine($"{p.Id}: {p.Name} <{p.Email}>");
        }

        public void CountMessagesBetween(Person p1, Person p2)
        {
            int count = messages.Count(m => (m.Sender == p1 && m.Receiver == p2) || (m.Sender == p2 && m.Receiver == p1));
            Console.WriteLine($"Messages between {p1.Name} and {p2.Name}: {count}");
        }

        public void PrintMessagesBetween(Person p1, Person p2)
        {
            var msgs = messages.Where(m => (m.Sender == p1 && m.Receiver == p2) || (m.Sender == p2 && m.Receiver == p1)).OrderBy(m => m.Date);
            foreach (var m in msgs)
                Console.WriteLine($"{m.Date}: {m.Sender.Name} -> {m.Receiver.Name}: {m.Text}");
        }

        public void PrintMessagesByDate(DateTime date)
        {
            var msgs = messages.Where(m => m.Date.Date == date.Date);
            foreach (var m in msgs)
                Console.WriteLine($"{m.Date}: {m.Sender.Name} -> {m.Receiver.Name}: {m.Text}");
        }

        public void PrintMessagesBySender(Person sender)
        {
            var msgs = messages.Where(m => m.Sender == sender);
            foreach (var m in msgs)
                Console.WriteLine($"{m.Date}: To {m.Receiver.Name}: {m.Text}");
        }

        public void SaveMessagesBetween(Person p1, Person p2, string path)
        {
            var msgs = messages.Where(m => (m.Sender == p1 && m.Receiver == p2) || (m.Sender == p2 && m.Receiver == p1));
            using (var writer = new System.IO.StreamWriter(path))
            {
                foreach (var m in msgs)
                    writer.WriteLine($"{m.Date}: {m.Sender.Name} -> {m.Receiver.Name}: {m.Text}");
            }
        }

        public void PrintUnseenMessages()
        {
            var unseen = messages.Where(m => !m.Seen);
            foreach (var m in unseen)
                Console.WriteLine($"{m.Sender.Name} -> {m.Receiver.Name}: {m.Text}");
        }

        public void ShowLastMessageWithForbidden(Person p, string forbiddenWord)
        {
            var last = messages.Where(m => m.Receiver == p).OrderByDescending(m => m.Date).FirstOrDefault();
            if (last != null)
            {
                string censored = last.Text.Replace(forbiddenWord, new string('*', forbiddenWord.Length));
                Console.WriteLine($"Last message to {p.Name}: {censored}");
            }
        }

        public Dictionary<Person, List<Person>> GetCorrespondents(int receiverId)
        {
            var receiver = GetPerson(receiverId);
            return messages.Where(m => m.Receiver == receiver).GroupBy(m => m.Sender).ToDictionary(g => g.Key, g => g.Select(m => m.Receiver).Distinct().ToList());
        }

        public void PrintAllMessagesOfPerson(Person person)
        {
            var allMsgs = messages.Where(m => m.Sender == person || m.Receiver == person).OrderBy(m => m.Date);
            foreach (var m in allMsgs)
                Console.WriteLine($"{m.Date}: {m.Sender.Name} -> {m.Receiver.Name}: {m.Text}");
        }

        public void GroupMessagesByPartOfDay()
        {
            var groups = messages.GroupBy(m =>
            {
                var hour = m.Date.Hour;
                if (hour < 12) return "Morning";
                if (hour < 18) return "Afternoon";
                return "Evening";
            });

            foreach (var group in groups)
            {
                Console.WriteLine($"\n{group.Key}:");
                foreach (var m in group)
                    Console.WriteLine($"{m.Date}: {m.Sender.Name} -> {m.Receiver.Name}: {m.Text}");
            }
        }

        public void SearchMessagesByKeyword(Person person, string keyword)
        {
            var found = messages.Where(m => (m.Sender == person || m.Receiver == person) && m.Text.ToLower().Contains(keyword.ToLower()));
            foreach (var m in found)
                Console.WriteLine($"{m.Date}: {m.Sender.Name} -> {m.Receiver.Name}: {m.Text}");
        }

        public List<(Person Person, List<Person> Correspondents)> GetPersonCorrespondentsStructure()
        {
            return people.Values.Select(p => (
                Person: p,
                Correspondents: messages.Where(m => m.Sender == p).Select(m => m.Receiver)
                                         .Concat(messages.Where(m => m.Receiver == p).Select(m => m.Sender))
                                         .Distinct().ToList()
            )).ToList();
        }
    }
}