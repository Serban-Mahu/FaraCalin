﻿using MedicalLoginSystemConsole.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Proiect
{
    internal class Manager
    {
        static List<string> users = new List<string>();
        static Dictionary<string, int> services = new Dictionary<string, int>();


        public static void ShowManagerMenu()
        {
            Console.WriteLine("\n============Manager Menu=============");
            Console.WriteLine("1-Add users: ");
            Console.WriteLine("2-Remove users: ");
            Console.WriteLine("3-List users: ");
            Console.WriteLine("4-Add Services: ");
            Console.WriteLine("5-Change price of a service: ");
            Console.WriteLine("6-Remove service: ");
            Console.WriteLine("7-Show services: ");
            Console.WriteLine("8-Change number of fidelity points: ");
        }
        public static void ChooseManagerOptions()
        {
        options:
            Console.WriteLine("Select your option");
            string opt = Console.ReadLine();
            switch (opt)
            {
                case "1":
                    AddUsers();
                    break;

                case "2":
                    ListUsers();
                    break;

                case "3":
                    RemoveUsers();
                    break;

                case "4":
                    AddServices();
                    break;

                case "5":
                    ChangePriceOfService();
                    break;

                case "6":
                    RemoveService();
                    break;

                case "7":
                    ShowServices();
                    break;

                case "8":
                    FidPointsMan();
                    break;

                default:
                    Console.WriteLine("Choose 1-8");
                    goto options;


            }

            static void AddUsers()
            {
                UserManager.Register();
            }

            static void RemoveUsers()
            {

                bool removed = false;
                string revuser = " ";
                while (!removed)
                {
                    Console.WriteLine("Enter the name of the user you want to remove: ");
                    revuser = Console.ReadLine();
                    users.Remove(revuser);
                    users = File.ReadAllLines("Users.txt").ToList();
                    removed = users.RemoveAll(u => u.Equals(revuser, StringComparison.CurrentCultureIgnoreCase)) > 0;
                    if (!removed)
                        Console.WriteLine("User has not been found. Try again");

                }
                Console.WriteLine($"User {revuser} has been removed ");
                Console.WriteLine("New list: ");
                ListUsers();

            }

            static void ListUsers()
            {

            }
        }
 
        static void AddServices()
        {
            Console.WriteLine("Enter the name of the service: ");
            string serviceName = Console.ReadLine()?.Trim();

            if (string.IsNullOrWhiteSpace(serviceName))
            {
                Console.WriteLine("Service name cannot be empty.");
                return;
            }

            if (services.ContainsKey(serviceName))
            {
                Console.WriteLine("This service already exists.");
                return;
            }

            Console.WriteLine("Enter the price of the service: ");
            if (!int.TryParse(Console.ReadLine(), out int price) || price < 0)
            {
                Console.WriteLine("Invalid price");
                return;
            }

            services.Add(serviceName, price);
            Console.WriteLine($"Service {serviceName} with price {price} has been added.");

            try
            {
                File.AppendAllLines("Services.txt", new[] { $"{serviceName},{price}" });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to save service: {ex.Message}");
            }
        }
        static void ChangePriceOfService()
        {
            Console.WriteLine("Enter the name of the service you want to change: ");
            string serviceName = Console.ReadLine()?.Trim();
            if (string.IsNullOrWhiteSpace(serviceName) || !services.ContainsKey(serviceName))
            {
                Console.WriteLine("Service not found.");
                return;
            }
            Console.WriteLine("Enter the new price: ");
            if (!int.TryParse(Console.ReadLine(), out int newPrice) || newPrice < 0)
            {
                Console.WriteLine("Invalid price");
                return;
            }
            services[serviceName] = newPrice;
            Console.WriteLine($"Service {serviceName} price changed to {newPrice}.");
            try
            {
                File.WriteAllLines("Services.txt", services.Select(s => $"{s.Key},{s.Value}"));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to update service: {ex.Message}");
            }
        }
        static void RemoveService()
        {
            Console.WriteLine("Enter the name of the service you want to remove: ");

        }
        static void ShowServices()
        {
            string[] sv;
            sv=File.ReadAllLines("Services.txt");
            foreach (string s in sv)
            {
                Console.WriteLine(s);

            }
        }
        static void FidPointsMan()
        {

        }
    }
}

