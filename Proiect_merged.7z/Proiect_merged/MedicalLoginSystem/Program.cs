﻿using MedicalLoginSystemConsole.Models;
using MedicalLoginSystemConsole.Services;

//Console.WriteLine("=== Medistra - Login & Registration ===");
//Console.WriteLine("A program designed for the authentication of patients and administrators.");
//Console.WriteLine("All data is stored locally and verified via an SMS code.\n");

bool showTitle = true;
string pathu = "Users.txt";


while (true)
{

    if (showTitle)
    {

        Console.WriteLine("=== Medistra – Login & Registration ===");
        Console.WriteLine("A program designed for the authentication of patients and administrators.");
        Console.WriteLine("All data is stored locally and verified via an SMS code.\n");

        showTitle = false;

    } else Console.Clear();

    //Console.Clear();

    Console.WriteLine("\n1. Register");
    Console.WriteLine("2. Login");
    Console.WriteLine("3. Exit");
    Console.Write("Choose an option: ");
    var option = Console.ReadLine();

    switch (option)
    {
        case "1":
            Console.Clear();
            UserManager.Register();
            showTitle = true;
            break;
        case "2":
            Console.Clear();
            UserManager.Login();
            showTitle = true;
            break;
        case "3":
            Console.WriteLine("Thank you for using our program!");
            return;
        default:
            Console.WriteLine("Invalid option. Please try again.");
            Thread.Sleep(1500);
            Console.Clear();
            break;
    }
}

