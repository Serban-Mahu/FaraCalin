﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MedicalLoginSystem
{
    public class Cart
    {
        private List<Service> services = new List<Service>();

        public void AddToCart(Service service)
        {
            services.Add(service);
        }

        public void SaveCart(string filePath = "cart.txt")
        {
            File.WriteAllLines(filePath, services.Select(s =>
                $"{s.Id},{s.Name},{s.Description},{s.Price},{s.Availability}"));
        }

        public void LoadCart(string filePath = "cart.txt")
        {
            services.Clear();
            if (!File.Exists(filePath)) return;
            foreach (var line in File.ReadAllLines(filePath))
            {
                try { services.Add(Service.FromString(line)); }
                catch { }
            }
        }

        public void ShowCart()
        {
            if (services.Count == 0)
            {
                Console.WriteLine("Cart is empty.");
                return;
            }
            foreach (var s in services)
            {
                Console.WriteLine($"ID: {s.Id} | Name: {s.Name} | Price: {s.Price}");
            }
        }
    }
}